%Import ScenarioTemplate.csv 
Input = ScenarioTemplate;

%Load Basic_Model
hws = get_param('Basic_Model', "ModelWorkspace");
Table = cell(18, 9);

%Set number of scenarios
z=9

%Process input data
for u=1:z
             Process{1,u}=1+(4.3*10^(-4)*Input{1,u}-(3.4*10^(-9)*Input{1,u}^2)); %Only for u<10.000 else 4.44+5.56.^(-5)*Input{1,u}
             Process{2,u}=Input{2,u};
             Process{3,u}=10-(0.3*Input{3,u});
             Process{4,u}=Input{4,u};
             Process{5,u}=Input{5,u};
             Process{6,u}=Input{6,u};
             Process{7,u}=Input{7,u};
             Process{8,u}=Input{8,u};
             Process{9,u}=Input{9,u};
             Process{10,u}=Input{10,u};
             Process{11,u}=Input{11,u};
             Process{12,u}=0.09*Input{12,u}+1;
             Process{13,u}=-0.09*Input{13,u}+10;
             Process{14,u}=0.173*10^(-3)*Input{14,u}+0.87;
             Process{15,u}=Input{15,u};
             Process{16,u}=0.09*Input{16,u}+1;
             Process{17,u}=0.09*Input{17,u}+1;
             Process{18,u}=-0.18*Input{18,u}+19;
             Process{19,u}=Input{19,u};
             Process{20,u}=0.025*Input{20,u}+1;
end

%Run simulation for scenarios
for i=1:z
            hws.assignin('Volume', Process{1,i});
            hws.assignin('Marketentrystrategy', Process{2,i});
            hws.assignin('Qualificationlevel', Process{3,i});
            hws.assignin('Importanceofeconomiesofscale', Process{4,i});
            hws.assignin('Productcost', Process{5,i});
            hws.assignin('Deliverytime', Process{6,i});
            hws.assignin('Quality', Process{7,i});
            hws.assignin('Importanceofflexibility', Process{8,i});
            hws.assignin('Importanceofinnovation', Process{9,i});
            hws.assignin('Importanceofenvironment', Process{10,i});
            hws.assignin('Importanceofsocial', Process{11,i});
            hws.assignin('Typeofproduct', Process{12,i});
            hws.assignin('Productcomplexity', Process{13,i});
            hws.assignin('Laborcosts', Process{14,i});clc
            hws.assignin('Marketdemand', Process{15,i});
            hws.assignin('Supplieravailability', Process{16,i});
            hws.assignin('Intracorporateressource', Process{17,i});
            hws.assignin('Availabilityoflocalworkforce', Process{18,i});
            hws.assignin('Fluctuationofworkforce', Process{19,i});
            hws.assignin('Energysupply', Process{20,i});
       
            sim('Basic_Model.slx');
            x{i}=Dataset;
            V{i}=x{i}.Data;
            R = V{i}(5,:)';
            B(i,1:18)=R;
        
end
%Process data 
            C=B';
            rowNames = {'Degree of automation', 'Production control', 'Depth of value added', 'Process choice', ...
                      'Process standardization',  'Process linkage', 'Operating material flexibility',...
                      'Operating material life-cycle', 'Level of inventory', 'Quality control',...
                      'Design stability','Worker training','Integration of society', 'Production technology',...
                       'Production network','Technology units','Number of expatriates','Incentives for employees'};
           Table = array2table(C,'RowNames',rowNames);
           
