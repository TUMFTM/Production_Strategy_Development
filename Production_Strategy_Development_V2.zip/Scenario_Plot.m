
%Number of scenarios
z = 9
%Bar plot of different scenarios
Szenarios = figure;
for n = 2:z
subplot(z,1,n-1);
bar(C(:,n));
ax=gca;
ax.XTick='';
ylabel(sprintf('Simulation #%d', n-1));
 %title(sprintf('Simulation', n,n));   
end 
set(gca, 'XTick', [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18])
set(gca, 'XTickLabel', rowNames')
xtickangle(90)

%Figure to compare min and max
Comparision = figure;

Min = min(C(:,2:z)');
Max = max(C(:,2:z)');
plot(Min,'DisplayName', 'Minimum value of simulations');
legend('-Dynamiclegend');
hold all 
plot (Max, 'DisplayName','Maximum value of simulations');
set(gca, 'XTick', [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18]);
set(gca, 'XTickLabel', rowNames');
xtickangle(90);
title('Comparision of simulations')

